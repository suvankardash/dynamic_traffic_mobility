mapInit() {
    alert("It's in!!");
}